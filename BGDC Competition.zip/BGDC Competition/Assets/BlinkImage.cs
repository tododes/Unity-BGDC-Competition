﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class BlinkImage : Image {

    private float blinkRate;
    private Color colorBlinkRate;

    private new void Start()
    {
        base.Start();
        blinkRate = 0f;
        colorBlinkRate = new Color(1, 1, 1, 1);
    }

    void Update()
    {
        blinkRate += Time.deltaTime * 5f;
        if (blinkRate >= 3.14f)
            blinkRate = 0f;
        colorBlinkRate.a = Mathf.Sin(blinkRate);
        this.color = colorBlinkRate;
    }
}
