﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : TodoBehaviour {

    public int maxHealth { get; protected set; }
    public int health { get; protected set; }

    private SkinnedMeshRenderer meshRender;
    private Canvas canvas;
    private ParticleSystem particleSystem;
    private float DelayToDestroy;
    private AudioSource audioSource;
    // Use this for initialization
    void Start () {
        maxHealth = health = 100;
        meshRender = C_C<SkinnedMeshRenderer>();
        particleSystem = C_C<ParticleSystem>();
        canvas = C_C<Canvas>();
        DelayToDestroy = 2f;
        particleSystem.startLifetime = DelayToDestroy;
        audioSource = C<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
		if(health <= 0f && health > -99){
            OnDead();
            health = -100;
        }
	}

    void OnTriggerEnter(Collider coll){
        if (coll.tag.Contains("Sword")){
            Sword sword = coll.GetComponent<Sword>();
            sword.PlaySoundEffect();
            if (sword.TimeToDamage == 1){
                Debug.Log("Attacked");
                health -= sword.Damage;
                sword.FinishAttack();
            }
        }
    }

    void OnDead(){
      
        StartCoroutine(DelayToDie());
    }

    IEnumerator DelayToDie()
    {
        particleSystem.Play();
        yield return new WaitForSeconds(0.8f);
        audioSource.Play();
        Ds(canvas);
        Ds(meshRender);
        yield return new WaitForSeconds(DelayToDestroy);
        DeAc(gameObject);
    }
}
