﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SplashScreenManager : MonoBehaviour {

    [SerializeField] private SettingsData settingsData;

    void Awake(){
        settingsData.SetVolumeSettings("Music", 1f);
        settingsData.SetVolumeSettings("SFX", 1f);
    }
	// Use this for initialization
	void Start () {
		
	}

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.KeypadEnter)){
            InterSceneImage.singleton.FinishScene("Main Menu");
        }
    }
}
