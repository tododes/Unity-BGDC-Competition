﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class TodoBehaviour : MonoBehaviour {

    public RectTransform rect
    {
        get { return C<RectTransform>(); }
        set { rect = value; }
    }

    public Vector3 pos
    {
        get { return transform.position; }
        set { pos = value; }
    }

    public Vector3 lpos
    {
        get { return transform.localPosition; }
        set { lpos = value; }
    }

    public Quaternion rot
    {
        get { return transform.rotation; }
        set { rot = value; }
    }

    public Quaternion lrot
    {
        get { return transform.localRotation; }
        set { lrot = value; }
    }

    public Vector3 sca
    {
        get { return transform.lossyScale; }
        set { sca = value; }
    }

    public Vector3 lsca
    {
        get { return transform.localScale; }
        set { lsca = value; }
    }

    public T C<T>() where T : Component
    {
        return GetComponent<T>();
    }

    public T C_C<T>() where T : Component
    {
        return GetComponentInChildren<T>();
    }

    public T C_P<T>() where T : Component
    {
        return GetComponentInParent<T>();
    }

    public T[] CS<T>() where T : Component
    {
        return GetComponents<T>();
    }

    public T[] CS_C<T>() where T : Component
    {
        return GetComponentsInChildren<T>();
    }

    public T[] CS_P<T>() where T : Component
    {
        return GetComponentsInParent<T>();
    }

    public Transform par
    {
        get{ return transform.parent; }
        set { par = value; }
    }

    public List<T> ListObj<T>() where T : Component
    {
        List<T> ListT = new List<T>();
        T[] ts = FindObjectsOfType<T>();
        for (int i = 0; i < ts.Length; i++)
        {
            ListT.Add(ts[i]);
        }
        return ListT;
    }

    public void T_A(Vector3 dir, float speed)
    {
        transform.Translate(dir * speed * Time.deltaTime);
    }

    public void R_A(Vector3 dir, float speed)
    {
        transform.Rotate(dir * speed * Time.deltaTime);
    }

    public void S_A(Vector3 inc, float speed)
    {
        transform.localScale += inc * speed * Time.deltaTime;
    }

    public void RT_A(Vector3 dir, float speed)
    {
        if(C<RectTransform>())
            C<RectTransform>().Translate(dir * speed * Time.deltaTime);
    }

    public void RR_A(Vector3 dir, float speed)
    {
        if (C<RectTransform>())
            C<RectTransform>().Rotate(dir * speed * Time.deltaTime);
    }

    public void RS_A(Vector3 inc, float speed)
    {
        if (C<RectTransform>())
            C<RectTransform>().localScale += inc * speed * Time.deltaTime;
    }

    public void En(MonoBehaviour comp)
    {
        if(!comp.enabled)
            comp.enabled = true;
    }

    public void Ds(MonoBehaviour comp)
    {
        if (comp.enabled)
            comp.enabled = false;
    }

    public void En(Renderer rend)
    {
        if (!rend.enabled)
            rend.enabled = true;
    }

    public void Ds(Renderer rend)
    {
        if (rend.enabled)
            rend.enabled = false;
    }

    public void En(Canvas c)
    {
        if (!c.enabled)
            c.enabled = true;
    }

    public void Ds(Canvas c)
    {
        if (c.enabled)
            c.enabled = false;
    }

    public void Ac(GameObject g)
    {
        g.SetActive(true);
    }

    public void DeAc(GameObject g)
    {
        g.SetActive(false);
    }

    public void Ac(MonoBehaviour g)
    {
        g.gameObject.SetActive(true);
    }

    public void DeAc(MonoBehaviour g)
    {
        g.gameObject.SetActive(false);
    }
}
