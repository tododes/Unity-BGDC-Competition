﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class DecisionPanel : TodoBehaviour {

    [SerializeField] private bool on;
    [SerializeField] private GameObject Yes, No, DecisionText;
    private Vector3 inc;
    private Vector3 nullifier;
    private Image image;
    
  
	// Use this for initialization
	void Start ()
    {
        inc = new Vector3(3.75f, 1.5f, 0);
        nullifier = new Vector3(0, 0, 0);
        image = C<Image>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (on && rect.localScale.x < 3f){
            if (!image.enabled)
                En(image);
            if (!Yes.activeInHierarchy)
                Ac(Yes);
            if (!No.activeInHierarchy)
                Ac(No);
            if (!DecisionText.activeInHierarchy)
                Ac(DecisionText);
            RS_A(inc, 1.25f);
        }
            
        if (!on && rect.localScale.x > 0f){
            RS_A(inc, -1.25f);
        }
        else if (!on && rect.localScale.x <= 0f){
            Ds(image);
            DeAc(Yes);
            DeAc(No);
            DeAc(DecisionText);
        }
    }

    public void On()
    {
        on = true;
    }

    public void Off()
    {
        on = false;
    }

    public void PressYes()
    {

    }

    public void PressNo()
    {

    }
}
