﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class SaveSlot : TodoBehaviour {

    [SerializeField] private SaveData saveData;
    [SerializeField] private SaveDatabase saveDB;
    [SerializeField] private PlayerData playerData;

    [SerializeField] private Text IDText;
    [SerializeField] private Text DateText;
    [SerializeField] private Text PlayerDataText;

    [SerializeField] private Player playerToBeSaved;

    private int index;

    void Awake()
    {
        index = (int)name[name.Length - 1] - '0';
        saveData = saveDB.getSaveDataInElement(index);
    }
    
    void Update()
    {
        if (saveData.ID > 0)
        {
            IDText.text = "ID : " + saveData.ID;
            DateText.text = "Date : " + saveData.saveYear + "/" + saveData.saveMonth + "/" + saveData.saveDay + " " + saveData.saveHour + " : " + +saveData.saveMinute + " : " + saveData.saveSecond;
            PlayerDataText.text = "Health : " + saveData.playerData.Health;
        }
        else
        {
            IDText.text = "ID : _ ";
            DateText.text = "Date : _";
            PlayerDataText.text = "Health : _";
        }
    }

    public void StoreData()
    {
        Debug.Log(gameObject.name + " pressed");
        if(saveData.ID == 0)
        {
            //saveData = playerData.currentSaveData;
            saveData.ID = Random.Range(100000, 1000000);
            saveData.playerData.Health = playerToBeSaved.getPlayerData().Health;
            //Debug.Log(playerToBeSaved.getPlayerData().Health);
            //Debug.Log(saveData.playerData.Health);
            saveData.saveYear = System.DateTime.Now.Year;
            saveData.saveMonth = System.DateTime.Now.Month;
            saveData.saveDay = System.DateTime.Now.Day;
            saveData.saveHour = System.DateTime.Now.Hour;
            saveData.saveMinute = System.DateTime.Now.Minute;
            saveData.saveSecond = System.DateTime.Now.Second;
            saveDB.FillSaveData(index, saveData);
        }
      
        //saveData.savedTime = System.DateTime.Now;
        //saveDB.FillSaveData(index, saveData);
        //Debug.Log(saveData.savedTime);
        //Debug.Log(saveDB.getSaveDataInElement(index).savedTime.Year);
    }

    public void RetrieveData()
    {
        playerData = saveData.playerData;
    }
}
