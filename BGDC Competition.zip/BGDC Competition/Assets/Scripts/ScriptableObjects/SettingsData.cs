﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SettingsData : ScriptableObject {

    [SerializeField] private List<string> audioStrings = new List<string>();
    [SerializeField] private List<float> audioValues = new List<float>();

    public void SetVolumeSettings(string volumeType, float volume){
        if (audioStrings.Contains(volumeType)){
            audioValues[audioStrings.IndexOf(volumeType)] = volume;
        }
        else{
            audioStrings.Add(volumeType);
            audioValues.Add(volume);
        }
    }

    public float getDataValue(string key){
        return audioValues[audioStrings.IndexOf(key)];
    }

    public void PrintData()
    {
  
    }

    public void ClearAllData(){
        audioStrings.Clear();
        audioValues.Clear();
    }
}
