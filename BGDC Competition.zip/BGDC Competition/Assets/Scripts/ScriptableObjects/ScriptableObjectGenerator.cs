﻿using UnityEngine;

#if UNITY_EDITOR
    using UnityEditor;
#endif

using System.Collections;

public class ScriptableObjectGenerator : MonoBehaviour
{
#if UNITY_EDITOR
    [MenuItem("Assets/Create/Save Database")]
    public static void CreateSaveDatabaseAsset()
    {
        SaveDatabase saveDatabase = ScriptableObject.CreateInstance<SaveDatabase>();
        AssetDatabase.CreateAsset(saveDatabase, "Assets/Scripts/ScriptableObjects/SaveDatabase.asset");
        AssetDatabase.SaveAssets();
    }
#endif

#if UNITY_EDITOR
    [MenuItem("Assets/Create/Settings Data")]
    public static void CreateSettingsDataAsset()
    {
        SettingsData sd = ScriptableObject.CreateInstance<SettingsData>();
        AssetDatabase.CreateAsset(sd, "Assets/Scripts/ScriptableObjects/SettingsData.asset");
        AssetDatabase.SaveAssets();
    }
#endif
}
