﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SaveDatabase : ScriptableObject
{
    [SerializeField] private SaveData[] savedData = new SaveData[3];

    public void FillSaveData(int index, SaveData sd)
    {
        if (savedData[index].ID == 0)
            savedData[index] = sd;
    }

    public SaveData getSaveDataInElement(int i)
    {
        return savedData[i];
    }
}
