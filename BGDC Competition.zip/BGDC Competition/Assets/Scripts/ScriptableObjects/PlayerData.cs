﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class PlayerData
{
    public float Health;
}
