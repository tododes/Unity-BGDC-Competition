﻿using UnityEngine;
using System.Collections;
using System;

[System.Serializable]
public class SaveData
{
    public int ID;
    public int saveYear, saveMonth, saveDay, saveHour, saveMinute, saveSecond;// = new DateTime();
    public PlayerData playerData;
}
