﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Player : TodoBehaviour
{

    [SerializeField]
    protected float maxHealth, health;
    [SerializeField]
    protected PlayerData data;
    protected List<GameObject> keys = new List<GameObject>();
    [SerializeField]
    protected Sword MySword;
    private Animator anim;
    private AnimatorStateInfo animInfo;
    private bool isAnimatingAttack;

    protected void Awake()
    {
        maxHealth = 100;
        health = 100;
    }

    protected void Start()
    {
        anim = C<Animator>();
        isAnimatingAttack = false;
    }

    protected void FixedUpdate(){
        transform.Rotate(0, Input.GetAxis("Mouse X") * 180f * Time.deltaTime, 0);
    }

    protected void Update()
    {
        if (health <= 0)
        {
            //Game Over
        }
        else
        {
            transform.Translate(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
            anim.SetBool("Walking", (Input.GetAxis("Horizontal") != 0f) || (Input.GetAxis("Vertical") != 0f));
            animInfo = anim.GetCurrentAnimatorStateInfo(0);
            if (keys.Count >= 3){
                //Open air terjun kehidupan
            }

            if (Input.GetMouseButtonDown(0)){
                if(!isAnimatingAttack){
                    anim.SetBool("Attack", true);
                    isAnimatingAttack = true;
                    animInfo = anim.GetCurrentAnimatorStateInfo(0);
                    MySword.Attack(15);
                    StartCoroutine(Animate(animInfo.length));
                }
            }
        }
    }

    protected IEnumerator Animate(float f){
        yield return new WaitForSeconds(f);
        isAnimatingAttack = false;
        anim.SetBool("Attack", false);
        MySword.Disable();
    }


    public float getMaxhealth(){ return maxHealth; }

    public void TakeDamage(int damage){
        health -= damage;
    }

    protected void OnTriggerEnter(Collider coll)
    {
        if (coll.name.Contains("Key"))
        {
            keys.Add(coll.gameObject);
        }
    }

    public float getHealth() { return health; }
    public void setHealth(int health) { this.health = health; }

    public PlayerData getPlayerData()
    {
        data.Health = health;
        return data;
    }
}
