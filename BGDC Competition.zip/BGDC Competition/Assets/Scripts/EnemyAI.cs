﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyAI : TodoBehaviour {

    private List<Ray> eyes = new List<Ray>();
    private RaycastHit hit;
    private int playerMask;
    [SerializeField ] private Player target;
    private NavMeshAgent agent;
    private Animator anim;
    private AnimatorStateInfo animInfo;
    private float walkIndex;

    [SerializeField] private float AttackAnimationCounter;
    private bool alreadyAttacked;
    // Use this for initialization
    void Start () {
        playerMask = LayerMask.GetMask("Player Mask");
        agent = C<NavMeshAgent>();
        anim = C<Animator>();
        alreadyAttacked = false;
    }
	
	// Update is called once per frame
	void Update () {
        eyes.Clear();
        for (float i = 0.5f; i < 1f; i += 0.125f){
            eyes.Add(new Ray(pos + Vector3.up * 0.5f, Vector3.Lerp(transform.forward, (transform.right * -1f), 1f - i)));
        }

        for (float i = 0; i <= 0.5f; i += 0.125f){
            eyes.Add(new Ray(pos + Vector3.up * 0.5f, Vector3.Lerp(transform.forward, transform.right, i)));
        }
        if (!target)
            target = getPlayerOnSight();
        else{
            agent.SetDestination(target.transform.position);
        }
        walkIndex = (target) ? 1f : 0f;
        anim.SetFloat("Walk", walkIndex);
        if (walkIndex >= 1f){
            anim.SetFloat("Distance", Vector3.Distance(transform.position, target.transform.position));
        }
      
        animInfo = anim.GetCurrentAnimatorStateInfo(0);
        if (animInfo.IsName("Armature|Attack")){
            AttackAnimationCounter += Time.deltaTime;
            if (AttackAnimationCounter >= 1f && !alreadyAttacked){
                //StartCoroutine(WaitAnimToFinish(animInfo.length - AttackAnimationCounter));
                target.TakeDamage(10);
                alreadyAttacked = true;
            }
            if (AttackAnimationCounter >= animInfo.length){
                AttackAnimationCounter -= animInfo.length;
                alreadyAttacked = false;
            }
        }
        else{
            AttackAnimationCounter = 0f;
        }
        //animInfo.length
    }

    //protected IEnumerator WaitAnimToFinish(float f)
    //{
    //    yield return new WaitForSeconds(f);
    //    target.TakeDamage(10);
    //    alreadyAttacked = false;
    //    AttackAnimationCounter = 0f;

    //}

    protected Player getPlayerOnSight()
    {
        foreach(Ray r in eyes){
            Debug.DrawRay(r.origin, r.direction, Color.blue);
            if(Physics.Raycast(r, out hit, 15f, playerMask)){
                Debug.Log(hit.collider.name);
                Player player = hit.collider.GetComponent<Player>();
                return player;
            }
        }
        return null;
    }
}
