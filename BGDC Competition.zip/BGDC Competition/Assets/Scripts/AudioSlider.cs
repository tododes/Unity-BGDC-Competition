﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class AudioSlider : Slider {

    private new void Start()
    {
        base.Start();
        if(!PlayerPrefs.HasKey("Audio"))
            PlayerPrefs.SetFloat("Audio", 1f);
        value = PlayerPrefs.GetFloat("Audio");
    }
    
    public void SetVolume(){
        PlayerPrefs.SetFloat("Audio", value);
    }

    private void Update(){
        Debug.Log(PlayerPrefs.GetFloat("Audio"));
    }
}
