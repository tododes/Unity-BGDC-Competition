﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using System;

public class MenuButton : TodoBehaviour, IPointerEnterHandler, IPointerExitHandler {

    private Dictionary<string, Action> buttonOnClickData = new Dictionary<string, Action>();
    [SerializeField] private Vector3 desiredSize, originalSize;


	// Use this for initialization
	void Start () {
        originalSize = Vector3.one;
        desiredSize = Vector3.one;
        buttonOnClickData.Add("Start", () =>
        {
            InterSceneImage.singleton.FinishScene("Test 2");
        });

        buttonOnClickData.Add("Option", () =>
        {
            InterSceneImage.singleton.FinishScene("Option");
        });

        buttonOnClickData.Add("Exit", () =>
        {
            MainMenu.singleton.getPanel().Trigger();
        });
    }

    public void ButtonOnClick()
    {
        Action action = buttonOnClickData[gameObject.name];
        action.Invoke();
    }
	
	// Update is called once per frame
	void Update () {
        if ((originalSize.x < desiredSize.x && rect.localScale.x < 1.3f) || (originalSize.x > desiredSize.x && rect.localScale.x > 1f))
            rect.localScale = rect.localScale + (desiredSize - originalSize) * Time.deltaTime * 3f;
	}

    public void OnPointerEnter(PointerEventData eventData)
    {
        desiredSize.x = desiredSize.y = 1.3f;
        originalSize.x = originalSize.y = 1f;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        desiredSize.x = desiredSize.y = 1f;
        originalSize.x = originalSize.y = 1.3f;
    }

}
