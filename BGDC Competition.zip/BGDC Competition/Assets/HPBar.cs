﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HPBar : Image {

    private Color desiredColor;
    private Vector2 desiredSize;
    private RectTransform rect;

    private Player player;

    void Awake(){
        base.Awake();
        desiredColor = new Color(0, 0, 0, 1);
        desiredSize = new Vector2(100, 100);
        rect = GetComponent<RectTransform>();
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
    }

    void Update(){
        desiredSize.x = (player.getHealth() * 100f) / player.getMaxhealth();
        rect.sizeDelta = desiredSize;
        desiredColor.g = 1f * (player.getHealth() / player.getMaxhealth());
        desiredColor.r = 1f * ((player.getMaxhealth() - player.getHealth()) / player.getMaxhealth());
        color = desiredColor;
    }
}
