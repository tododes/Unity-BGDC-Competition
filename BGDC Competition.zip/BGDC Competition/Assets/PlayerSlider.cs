﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerSlider : Slider {

    [SerializeField] private Enemy player;

    void Start(){
        player = transform.parent.parent.GetComponent<Enemy>();
        maxValue = player.maxHealth;
    }

	void Update () {
        value = player.health;
	}
}
