﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenu : MonoBehaviour {

    public static MainMenu singleton;

    [SerializeField]
    private AreYouSurePanel panel;

    public AreYouSurePanel getPanel(){
        return panel;
    }

	// Use this for initialization
	void Awake () {
        singleton = this;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
