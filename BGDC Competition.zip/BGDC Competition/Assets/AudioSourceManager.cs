﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioSourceManager : TodoBehaviour {

    [SerializeField] private SettingsData settingsData;
    private AudioSource audioSource;
	// Use this for initialization
	void Start () {
        settingsData.PrintData();
        audioSource = C<AudioSource>();
        audioSource.volume = settingsData.getDataValue(tag);
        audioSource.Play();
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
