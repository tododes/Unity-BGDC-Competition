﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SaveChangeButton : Button {

    private Slider MusicSlider, SFXSlider;
    [SerializeField]
    private SettingsData data;

    [SerializeField]
    private SettingsManager settingsManager;

	// Use this for initialization
	void Start () {
        MusicSlider = GameObject.Find("Music").GetComponent<Slider>();
        SFXSlider = GameObject.Find("SFX").GetComponent<Slider>();
        settingsManager = SettingsManager.singleton;
        onClick.AddListener(SaveChanges);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void SaveChanges(){
        settingsManager.SaveVolumeData(MusicSlider.name, MusicSlider.value);
        settingsManager.SaveVolumeData(SFXSlider.name, SFXSlider.value);
    }
}
