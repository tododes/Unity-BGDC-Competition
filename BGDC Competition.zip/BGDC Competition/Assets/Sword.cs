﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sword : TodoBehaviour {

    public int Damage { get; private set; }
    [SerializeField] public int TimeToDamage { get; private set; }
    [SerializeField] private AudioSource audioSource;
    // Use this for initialization
    void Start () {
        TimeToDamage = 0;
        audioSource = C_C<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void Attack(int Damage){
        this.Damage = Damage;
        TimeToDamage = 1;
    }

    public void FinishAttack(){
        TimeToDamage = 2;
    }

    public void Disable(){
        TimeToDamage = 0;
    }

    public void PlaySoundEffect(){
        audioSource.Play();
    }
}
