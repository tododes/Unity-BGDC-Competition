﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SettingsManager : MonoBehaviour {

    public static SettingsManager singleton;
    private string[] volumeKeys = { "Music", "SFX" };

    [SerializeField]
    private SettingsData settingsData;

    void Awake() {
        singleton = this;
        for (int i = 0; i < volumeKeys.Length; i++) {
            GameObject.Find(volumeKeys[i]).GetComponent<Slider>().value = settingsData.getDataValue(volumeKeys[i]);
        }
    }

    public void SaveVolumeData(string key, float value){
        settingsData.SetVolumeSettings(key, value);
    }

}
